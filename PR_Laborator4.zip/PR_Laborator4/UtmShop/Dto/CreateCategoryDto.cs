﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UtmShop.Dto
{
    public class CreateCategoryDto
    {
        public string Title { get; set; }
    }
}
