﻿using Newtonsoft.Json;
using System.Text;
using UtmShop.Dto;

// Create HTTP client
var client = new HttpClient();

// Set base address for API
client.BaseAddress = new Uri("https://localhost:44370/api/");

// Display menu and handle user input
bool exit = false;
while (!exit)
{
    Console.WriteLine("\nMenu:");
    Console.WriteLine("1. List categories");
    Console.WriteLine("2. Category details");
    Console.WriteLine("3. Create new category");
    Console.WriteLine("4. Delete category");
    Console.WriteLine("5. Update category title");
    Console.WriteLine("6. Create new product in category");
    Console.WriteLine("7. List products in category");
    Console.WriteLine("0. Exit");

    Console.Write("\nEnter option: ");
    var option = Console.ReadLine();

    switch (option)
    {
        case "1":
            await ListCategories(client);
            break;

        case "2":
            await CategoryDetails(client);
            break;

        case "3":
            await CreateCategory(client);
            break;

        case "4":
            await DeleteCategory(client);
            break;

        case "5":
            await UpdateCategoryTitle(client);
            break;

        case "6":
            await CreateProduct(client);
            break;

        case "7":
            await ListProductsInCategory(client);
            break;

        case "0":
            exit = true;
            break;

        default:
            Console.WriteLine("  Optiune invalida. Incearca din nou.");
            break;
    }
}

static async Task ListCategories(HttpClient client)
{
    var response = await client.GetAsync("Category/categories");
    if (response.IsSuccessStatusCode)
    {
        var content = await response.Content.ReadAsStringAsync();
        var categories = JsonConvert.DeserializeObject<CategoryShortDto[]>(content);

        Console.WriteLine("\nCategories:");
        foreach (CategoryShortDto category in categories!)
        {
            Console.WriteLine($"  {category.Id}. {category.Name} - {category.ItemsCount}");
        }
    }
    else
    {
        Console.WriteLine($"Error retrieving categories: {response.StatusCode}");
    }
}

static async Task CategoryDetails(HttpClient client)
{
    Console.Write("\nEnter category ID: ");
    var categoryId = Console.ReadLine();

    var response = await client.GetAsync($"Category/categories/{categoryId}");
    if (response.IsSuccessStatusCode)
    {
        var content = await response.Content.ReadAsStringAsync();
        var categories = JsonConvert.DeserializeObject<IList<CategoryShortDto>>(content);

        foreach (var category in categories!)
        {
            Console.WriteLine($"  ID: {categoryId}");
            Console.WriteLine($"  Name: {category.Name}");
            Console.WriteLine($"  Items count: {category.ItemsCount}");
        }
    }
    else
    {
        Console.WriteLine($"Error retrieving category details: {response.StatusCode}");
    }
}

static async Task CreateCategory(HttpClient client)
{
    Console.Write("\nEnter category title: ");
    var title = Console.ReadLine();

    var newCategory = new CreateCategoryDto { Title = title! };
    var serializedCategory = JsonConvert.SerializeObject(newCategory);
    var contentP = new StringContent(serializedCategory, Encoding.UTF8, "application/json");

    var response = await client.PostAsync("Category/categories", contentP);
    if (response.IsSuccessStatusCode)
    {
        var createdCategory = await response.Content.ReadAsStringAsync();
        var category = JsonConvert.DeserializeObject<CategoryShortDto>(createdCategory);

        Console.WriteLine($"Category created with ID {category!.Id} and name {category.Name}.");
    }
    else
    {
        Console.WriteLine($"Error creating category: {response.StatusCode}");
    }
}

static async Task DeleteCategory(HttpClient client)
{
    Console.Write("\nEnter category ID to delete: ");
    var categoryId = Console.ReadLine();

    var response = await client.DeleteAsync($"Category/categories/{categoryId}");

    if (response.IsSuccessStatusCode)
    {
        Console.WriteLine($"Category with ID {categoryId} deleted successfully.");
    }
    else
    {
        Console.WriteLine($"Error deleting category: {response.StatusCode}");
    }
}

static async Task UpdateCategoryTitle(HttpClient client)
{
    Console.Write("\nEnter category ID to update: ");
    var categoryId = Console.ReadLine();

    var response = await client.GetAsync($"Category/categories/{categoryId}");
    if (!response.IsSuccessStatusCode)
    {
        if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            Console.WriteLine($"Category with ID {categoryId} not found.");
        }
        else
        {
            Console.WriteLine($"Error retrieving category details: {response.StatusCode}");
        }
        return;
    }

    Console.Write("\nEnter new category title: ");
    var newTitle = Console.ReadLine();

    var categoryToUpdate = new CreateCategoryDto { Title = newTitle! };
    var serializedCategoryToUpdate = JsonConvert.SerializeObject(categoryToUpdate);
    var contentU = new StringContent(serializedCategoryToUpdate, Encoding.UTF8, "application/json");

    response = await client.PutAsync($"Category/{categoryId}", contentU);
    if (response.IsSuccessStatusCode)
    {
        var updatedCategory = await response.Content.ReadAsStringAsync();
        var category = JsonConvert.DeserializeObject<CategoryShortDto>(updatedCategory);

        Console.WriteLine($"Category with ID {category!.Id} updated successfully with new title {category.Name}.");
    }
    else
    {
        Console.WriteLine($"Error updating category: {response.StatusCode}");
    }
}

static async Task CreateProduct(HttpClient client)
{
    Console.Write("\nEnter category ID: ");
    var categoryId2 = Console.ReadLine();

    // Validate category ID
    if (!long.TryParse(categoryId2, out long categoryIdParsed2))
    {
        Console.WriteLine("Invalid category ID. Please enter a number.");
        return;
    }

    Console.Write("\nEnter product name: ");
    var productName = Console.ReadLine();

    Console.Write("\nEnter product price: ");
    var productPrice = Console.ReadLine();

    // Validate product price
    if (!decimal.TryParse(productPrice, out decimal productPriceParsed))
    {
        Console.WriteLine("Invalid product price. Please enter a number.");
        return;
    }

    var newProduct = new ProductShortDto
    {
        Title = productName!,
        Price = productPriceParsed
    };

    var serializedProduct = JsonConvert.SerializeObject(newProduct);
    var contentProduct = new StringContent(serializedProduct, Encoding.UTF8, "application/json");

    var response = await client.PostAsync($"Category/categories/{categoryIdParsed2}/products", contentProduct);

    if (response.IsSuccessStatusCode)
    {
        var createdProduct = await response.Content.ReadAsStringAsync();
        var product = JsonConvert.DeserializeObject<ProductShortDto>(createdProduct);

        Console.WriteLine($"Product created with ID {product!.Id} and name {product.Title}.");
    }
    else
    {
        Console.WriteLine($"Error updating category: {response.StatusCode}");
    }
}

static async Task ListProductsInCategory(HttpClient client)
{
    Console.Write("\n Introdu ID-ul categoriei pentru a vedea produsele: ");
    var categoryId = Console.ReadLine();

    var response = await client.GetAsync($"Category/categories/{categoryId}/products");
    if (response.IsSuccessStatusCode)
    {
        var content = await response.Content.ReadAsStringAsync();
        var products = JsonConvert.DeserializeObject<IList<ProductShortDto>>(content);

        Console.WriteLine($"\n Lista produselor din categoria cu ID-ul {categoryId}:");
        foreach (ProductShortDto product in products!)
        {
            Console.WriteLine($"  {product.Id}. {product.Title} - {product.Price} Lei");
        }
    }
    else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
    {
        Console.WriteLine($"Categoria cu ID-ul {categoryId} nu a fost gasita.");
    }
    else
    {
        Console.WriteLine($"Eroare: {response.StatusCode}");
    }
}